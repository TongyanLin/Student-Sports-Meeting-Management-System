package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import javax.persistence.*;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import static javax.persistence.GenerationType.IDENTITY;

@Entity
@Table(name = "projects", schema = "sport")
@JsonIgnoreProperties(value = {"handler","hibernateLazyInitializer","fieldHandler"})
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "projectId")
public class Project {
    private int projectId;
    private String name;
    private String date;

    private Set<ProjectAthlete> athletes=new HashSet<>();
    private Set<ProjectReferee> referees=new HashSet<>();

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = IDENTITY)
    public int getProjectId() {
        return projectId;
    }
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }


    @Basic
    @Column(name = "name")
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "date")
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }


    @OneToMany(mappedBy = "project")
    public Set<ProjectAthlete> getAthletes() {
        return athletes;
    }
    public void setAthletes(Set<ProjectAthlete> athletes) {
        this.athletes = athletes;
    }

    @OneToMany(mappedBy = "project")
    public Set<ProjectReferee> getReferees() {
        return referees;
    }
    public void setReferees(Set<ProjectReferee> referees) {
        this.referees = referees;
    }
}

package com.example.demo.dao;

import com.example.demo.entity.ProjectReferee;

public interface ProjectRefereeDao {
    ProjectReferee getState(Integer userId, Integer projectId);
    void selectOne(Integer userId, Integer projectId);

}

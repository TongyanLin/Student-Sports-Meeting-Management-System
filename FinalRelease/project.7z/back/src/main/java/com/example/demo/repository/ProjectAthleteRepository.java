package com.example.demo.repository;

import com.example.demo.entity.ProjectAthlete;
import com.example.demo.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface ProjectAthleteRepository  extends JpaRepository<ProjectAthlete, Integer>{
    @Query(value = "SELECT * FROM PROJECT_ATHLETE WHERE athlete_id = ?1 and project_id = ?2",
            nativeQuery = true)
    ProjectAthlete getState(@Param("athlete_id")Integer userId, @Param("project_id")Integer projectId);
}
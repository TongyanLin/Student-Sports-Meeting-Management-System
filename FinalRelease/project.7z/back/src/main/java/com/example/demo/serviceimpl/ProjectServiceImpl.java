package com.example.demo.serviceimpl;

import com.example.demo.dao.ProjectDao;
import com.example.demo.dao.ProjectAthleteDao;
import com.example.demo.dao.ProjectRefereeDao;
import com.example.demo.entity.Project;
import com.example.demo.entity.ProjectAthlete;
import com.example.demo.entity.ProjectReferee;
import com.example.demo.entity.User;
import com.example.demo.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ProjectServiceImpl implements ProjectService {

    @Autowired
    private ProjectDao projectDao;

    @Autowired
    private ProjectAthleteDao projectAthleteDao;

    @Autowired
    private ProjectRefereeDao projectRefereeDao;

    @Override
    public List<Project> getProjects(){return projectDao.getAll();}

    @Override
    public Project findProject(Integer id){
        return projectDao.findProject(id);
    }

    @Override
    public int getState(Integer userId, Integer projectId) {
        ProjectAthlete x=projectAthleteDao.getState(userId,projectId);
        if(x!=null){
            return x.getState();
        }
        return 0;
    }

    @Override
    public int signup(Integer userId, Integer projectId) {
        projectAthleteDao.signup(userId,projectId);
        return 0;
    }

    @Override
    public int getState3(Integer userId, Integer projectId) {
        ProjectReferee x=projectRefereeDao.getState(userId,projectId);
        if(x!=null){
            return 1;
        }
        return 0;
    }

    @Override
    public int changeName(Integer projectId,String name) {
        projectDao.changeName(projectId,name);
        return 0;
    }

    @Override
    public int changeDate(Integer projectId,String date) {
        projectDao.changeDate(projectId,date);
        return 0;
    }

    @Override
    public int add() {
        projectDao.add();
        return 1;
    }

    @Override
    public int delete(Integer projectId) {
        projectDao.delete(projectId);
        return 1;
    }

    @Override
    public int adopt(Integer userId, Integer projectId) {
        projectAthleteDao.adopt(userId,projectId);
        return 0;
    }

    @Override
    public int selectOne(Integer userId, Integer projectId) {
        projectRefereeDao.selectOne(userId,projectId);
        return 0;
    }

    @Override
    public int changeGrade(Integer userId,Integer projectId,String grade) {
        projectAthleteDao.changeGrade(userId,projectId,grade);
        return 0;
    }
}
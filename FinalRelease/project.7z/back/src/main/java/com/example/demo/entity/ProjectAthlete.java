package com.example.demo.entity;

import javax.persistence.*;
import java.io.Serializable;

import static javax.persistence.GenerationType.IDENTITY;

@Entity
@Table(name = "project_athlete", schema = "sport")
public class ProjectAthlete implements Serializable {
    private int id;
    private Project project;
    private User athlete;
    private String grade;
    private int state;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = IDENTITY)
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    @ManyToOne
    @JoinColumn(name = "project_id", referencedColumnName = "id")
    public Project getProject() { return project; }
    public void setProject(Project project) { this.project = project; }

    @ManyToOne(targetEntity = User.class, cascade={CascadeType.MERGE,CascadeType.REFRESH},optional=false)
    @JoinColumn(name = "athlete_id", referencedColumnName = "id")
    public User getAthlete() { return athlete; }
    public void setAthlete(User athlete) { this.athlete = athlete; }

    @Basic
    @Column(name = "grade")
    public String getGrade() { return grade; }
    public void setGrade(String grade) {
        this.grade = grade;
    }

    @Basic
    @Column(name = "state")
    public int getState() { return state; }
    public void setState(int state) { this.state = state; }

}

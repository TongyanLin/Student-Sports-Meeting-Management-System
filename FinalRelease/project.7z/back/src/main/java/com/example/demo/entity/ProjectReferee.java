package com.example.demo.entity;

import javax.persistence.*;
import java.io.Serializable;

import static javax.persistence.GenerationType.IDENTITY;

@Entity
@Table(name = "project_referee", schema = "sport")
public class ProjectReferee implements Serializable {
    private int id;
    private Project project;
    private User referee;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = IDENTITY)
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    @ManyToOne
    @JoinColumn(name = "project_id", referencedColumnName = "id")
    public Project getProject() { return project; }
    public void setProject(Project project) { this.project = project; }

    @ManyToOne(targetEntity = User.class, cascade={CascadeType.MERGE,CascadeType.REFRESH},optional=false)
    @JoinColumn(name = "referee_id", referencedColumnName = "id")
    public User getReferee() { return referee; }
    public void setReferee(User referee) { this.referee = referee; }


}

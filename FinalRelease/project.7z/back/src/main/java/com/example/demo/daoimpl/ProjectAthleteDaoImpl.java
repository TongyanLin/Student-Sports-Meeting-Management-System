package com.example.demo.daoimpl;

import com.example.demo.dao.ProjectAthleteDao;
import com.example.demo.entity.Project;
import com.example.demo.entity.User;
import com.example.demo.entity.ProjectAthlete;
import com.example.demo.repository.ProjectRepository;
import com.example.demo.repository.ProjectAthleteRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository
public class ProjectAthleteDaoImpl implements ProjectAthleteDao {
    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProjectAthleteRepository projectAthleteRepository;

    @Override
    public ProjectAthlete getState(Integer userId,Integer projectId){
        return projectAthleteRepository.getState(userId,projectId);
    }

    @Override
    @Transactional
    public void signup(Integer userId, Integer projectId){

        Project project=projectRepository.getOne(projectId);
        User athlete=userRepository.getOne(userId);


        ProjectAthlete projectAthlete=new ProjectAthlete();
        projectAthlete.setAthlete(athlete);
        projectAthlete.setProject(project);
        projectAthlete.setState(1);

        projectAthleteRepository.save(projectAthlete);

        User res=userRepository.save(athlete);

        System.out.println("after insert res: " + res);
    }

    @Override
    @Transactional
    public void adopt(Integer userId, Integer projectId){

        Project project=projectRepository.getOne(projectId);
        User athlete=userRepository.getOne(userId);

        ProjectAthlete projectAthlete=projectAthleteRepository.getState(userId,projectId);

        projectAthlete.setState(2);

        projectAthleteRepository.save(projectAthlete);
    }

    @Override
    @Transactional
    public void changeGrade(Integer userId,Integer projectId,String grade){

        Project project=projectRepository.getOne(projectId);
        User athlete=userRepository.getOne(userId);

        ProjectAthlete projectAthlete=projectAthleteRepository.getState(userId,projectId);

        projectAthlete.setGrade(grade);

        projectAthleteRepository.save(projectAthlete);
    }

}
package com.example.demo.dao;

import com.example.demo.entity.User;

import java.util.List;

public interface UserDao {
    User checkUser(String username, String password);
    List<User> referees();
}


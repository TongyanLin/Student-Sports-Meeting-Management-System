package com.example.demo.controller;

import com.example.demo.entity.Project;
import com.example.demo.entity.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @CrossOrigin
    @GetMapping(value = "/login")
    public int user(@RequestParam("username") String username, @RequestParam("psd") String password,
                         HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin", request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");

        User user = userService.checkUser(username, password);
        if(user != null){
            System.out.println("true");
            int type=user.getType();
            HttpSession hs = request.getSession();
            hs.setAttribute("user_id", user.getUserId());
            hs.setAttribute("username", username);
            hs.setAttribute("password", password);
            hs.setAttribute("type", user.getType());
            System.out.println(hs.getAttribute("type"));
            return type;
        }
        else{
            return -1;
        }

    }

    @CrossOrigin
    @GetMapping(value = "/referees")
    public List<User> referees(HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin", request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");
        List<User> referees=userService.referees();
        System.out.println(referees.size());
        return referees;
    }
}

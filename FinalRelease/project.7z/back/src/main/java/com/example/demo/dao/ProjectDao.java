package com.example.demo.dao;

import com.example.demo.entity.Project;

import java.util.List;

public interface ProjectDao {
    List<Project> getAll();
    Project findProject(Integer id);
    int changeName(Integer projectId,String name);
    int changeDate(Integer projectId,String date);
    int add();
    int delete(Integer projectId);

}
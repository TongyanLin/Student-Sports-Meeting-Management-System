package com.example.demo.dao;

import com.example.demo.entity.ProjectAthlete;
import com.example.demo.entity.User;

public interface ProjectAthleteDao {
    ProjectAthlete getState(Integer userId, Integer projectId);
    void signup(Integer userId, Integer projectId);
    void adopt(Integer userId, Integer projectId);
    void changeGrade(Integer userId,Integer projectId,String grade);
}
package com.example.demo.daoimpl;

import com.example.demo.dao.ProjectDao;
import com.example.demo.entity.Project;
import com.example.demo.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Repository
public class ProjectDaoImpl implements ProjectDao {
    @Autowired
    private ProjectRepository projectRepository;

    @Override
    public List<Project> getAll(){return projectRepository.findAll();}

    @Override
    public Project findProject(Integer id){
        return projectRepository.getOne(id);
    }

    @Override
    @Transactional
    public int changeName(Integer projectId,String name) {
        Project project=projectRepository.getOne(projectId);
        project.setName(name);
        projectRepository.save(project);
        return 0;
    }

    @Override
    @Transactional
    public int changeDate(Integer projectId,String date) {
        Project project=projectRepository.getOne(projectId);
        project.setDate(date);
        projectRepository.save(project);
        return 0;
    }

    @Override
    @Transactional
    public int add() {
        Project project=new Project();
        projectRepository.save(project);
        return 0;
    }

    @Override
    @Transactional
    public int delete(Integer projectId) {
        Project project=projectRepository.getOne(projectId);
        projectRepository.delete(project);
        return 1;
    }
}
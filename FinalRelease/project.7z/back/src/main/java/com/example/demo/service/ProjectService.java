package com.example.demo.service;

import com.example.demo.entity.Project;

import java.util.List;

public interface ProjectService {
    List<Project> getProjects();
    Project findProject(Integer id);
    int getState(Integer userId,Integer projectId);
    int signup(Integer userId,Integer projectId);
    int getState3(Integer userId,Integer projectId);
    int changeName(Integer projectId,String name);
    int changeDate(Integer projectId,String date);
    int add();
    int delete(Integer projectId);
    int adopt(Integer userId,Integer projectId);
    int selectOne(Integer userId,Integer projectId);
    int changeGrade(Integer userId,Integer projectId,String grade);
}
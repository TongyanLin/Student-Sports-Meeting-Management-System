package com.example.demo.controller;

import com.example.demo.entity.Project;
import com.example.demo.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
public class ProjectController {

    @Autowired
    private ProjectService projectService;

    @CrossOrigin
    @GetMapping(value = "/projects")
    public List<Project> getProjects(
                         HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");
        System.out.println("projects");
        return projectService.getProjects();
    }

    @CrossOrigin
    @GetMapping(value = "/findProject")
    public Project findProject(@RequestParam("id") Integer id,
            HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");
        System.out.println("project");

        return projectService.findProject(id);
    }

    @CrossOrigin
    @GetMapping(value = "/getState")
    public int getState(@RequestParam("id") Integer projectId,
                               HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");

        HttpSession hs = request.getSession();
        int userId = (int) hs.getAttribute("user_id");
        int state=projectService.getState(userId,projectId);
        System.out.println(state);
        return state;
    }

    @CrossOrigin
    @GetMapping(value = "/signup")
    public int signup(@RequestParam("id") Integer projectId,
                        HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");

        HttpSession hs = request.getSession();
        int userId = (int) hs.getAttribute("user_id");
        System.out.println("a");
        projectService.signup(userId,projectId);
        return 0;
    }

    @CrossOrigin
    @GetMapping(value = "/getState3")
    public int getState3(@RequestParam("id") Integer projectId,
                        HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");
        System.out.println("aa");
        HttpSession hs = request.getSession();
        int userId = (int) hs.getAttribute("user_id");
        System.out.println("bb");
        int state=projectService.getState3(userId,projectId);
        System.out.println(state);
        return state;
    }

    @CrossOrigin
    @GetMapping(value = "/changeName")
    public int changeName(@RequestParam("id") Integer projectId,@RequestParam("name") String name,
                         HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");
        System.out.println(name);
        int state=projectService.changeName(projectId,name);
        System.out.println(state);
        return state;
    }

    @CrossOrigin
    @GetMapping(value = "/changeDate")
    public int changeDate(@RequestParam("id") Integer projectId,@RequestParam("date") String date,
                          HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");
        System.out.println(date);
        int state=projectService.changeDate(projectId,date);
        System.out.println(state);
        return state;
    }

    @CrossOrigin
    @GetMapping(value = "/add")
    public int add(HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");

        int state=projectService.add();
        System.out.println(state);
        return state;
    }

    @CrossOrigin
    @GetMapping(value = "/delete")
    public int delete(@RequestParam("id") Integer projectId,
                          HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");
        int state=projectService.delete(projectId);
        System.out.println(state);
        return state;
    }

    @CrossOrigin
    @GetMapping(value = "/adopt")
    public int adopt(@RequestParam("id") Integer projectId,@RequestParam("userId") Integer userId,
                      HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");

        projectService.adopt(userId,projectId);
        return 0;
    }

    @CrossOrigin
    @GetMapping(value = "/select")
    public int select(@RequestParam("id") Integer projectId,@RequestParam("userId") Integer userId,
                         HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");

        int state=projectService.getState3(userId,projectId);
        System.out.println(state);
        return state;
    }

    @CrossOrigin
    @GetMapping(value = "/selectOne")
    public int selectOne(@RequestParam("id") Integer projectId,@RequestParam("userId") Integer userId,
                      HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");

        int state=projectService.selectOne(userId,projectId);
        System.out.println(state);
        return state;
    }

    @CrossOrigin
    @GetMapping(value = "/changeGrade")
    public int changeGrade(@RequestParam("id") Integer projectId,
                           @RequestParam("userId") Integer userId,
                           @RequestParam("grade") String grade,
                         HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin",request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Credentials", "true");

        int state=projectService.changeGrade(userId,projectId,grade);
        System.out.println(state);
        return state;
    }
}

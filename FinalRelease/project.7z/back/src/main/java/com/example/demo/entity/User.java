package com.example.demo.entity;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import javax.persistence.*;

import java.util.HashSet;
import java.util.Set;

import static javax.persistence.GenerationType.IDENTITY;


@Entity
@Table(name = "users", schema = "sport")
@JsonIgnoreProperties(value = {"handler","hibernateLazyInitializer","fieldHandler"})
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "userId")
public class User {

    private int userId;
    private String username;
    private String password;
    private int type;

    private Set<ProjectAthlete> projects=new HashSet<>();
    private Set<ProjectReferee> projects2=new HashSet<>();

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = IDENTITY)
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "username")
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    @Basic
    @Column(name = "password")
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    @Basic
    @Column(name = "user_type")
    public int getType() {
        return type;
    }
    public void setType(int type) {
        this.type = type;
    }


    @OneToMany(targetEntity = ProjectAthlete.class, cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name = "athlete_id", referencedColumnName = "id")
    public Set<ProjectAthlete> getProjects() {
        return projects;
    }
    public void setProjects(Set<ProjectAthlete> projects) {
        this.projects = projects;
    }

    @OneToMany(targetEntity = ProjectReferee.class, cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name = "referee_id", referencedColumnName = "id")
    public Set<ProjectReferee> getProjects2() {
        return projects2;
    }
    public void setProjects2(Set<ProjectReferee> projects2) {
        this.projects2 = projects2;
    }

}
package com.example.demo.repository;

import com.example.demo.entity.ProjectReferee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ProjectRefereeRepository extends JpaRepository<ProjectReferee, Integer> {
    @Query(value = "SELECT * FROM PROJECT_REFEREE WHERE referee_id = ?1 and project_id = ?2",
            nativeQuery = true)
    ProjectReferee getState(@Param("athlete_id")Integer userId, @Param("project_id")Integer projectId);
}

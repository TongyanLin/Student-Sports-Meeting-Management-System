package com.example.demo.daoimpl;

import com.example.demo.dao.ProjectRefereeDao;
import com.example.demo.entity.Project;
import com.example.demo.entity.ProjectAthlete;
import com.example.demo.entity.ProjectReferee;
import com.example.demo.entity.User;
import com.example.demo.repository.ProjectAthleteRepository;
import com.example.demo.repository.ProjectRefereeRepository;
import com.example.demo.repository.ProjectRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class ProjectRefereeDaoImpl implements ProjectRefereeDao {
    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProjectRefereeRepository projectRefereeRepository;

    @Override
    public ProjectReferee getState(Integer userId, Integer projectId){
        return projectRefereeRepository.getState(userId,projectId);
    }

    @Override
    @Transactional
    public void selectOne(Integer userId, Integer projectId){
        Project project=projectRepository.getOne(projectId);
        User referee=userRepository.getOne(userId);

        ProjectReferee projectReferee=new ProjectReferee();
        projectReferee.setReferee(referee);
        projectReferee.setProject(project);

        projectRefereeRepository.save(projectReferee);

        User res=userRepository.save(referee);
    }
}

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', 'lty', '123456', 0);
INSERT INTO `users` VALUES ('2', 'aaa', '123456', 1);
INSERT INTO `users` VALUES ('3', 'bbb', '123456', 2);
INSERT INTO `users` VALUES ('4', 'ccc', '123456', 2);
INSERT INTO `users` VALUES ('5', 'ddd', '123456', 1);
INSERT INTO `users` VALUES ('6', 'eee', '123456', 2);
INSERT INTO `users` VALUES ('7', 'fff', '123456', 2);
INSERT INTO `users` VALUES ('8', 'ggg', '123456', 1);
INSERT INTO `users` VALUES ('9', 'hhh', '123456', 2);
INSERT INTO `users` VALUES ('10', 'iii', '123456', 2);
INSERT INTO `users` VALUES ('11', 'jjj', '123456', 1);
INSERT INTO `users` VALUES ('12', 'kkk', '123456', 2);

-- ----------------------------
-- Table structure for projects
-- ----------------------------
DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for project_athlete
-- ----------------------------
DROP TABLE IF EXISTS `project_athlete`;
CREATE TABLE `project_athlete` (
  `id` int(11) NOT NULL auto_increment,
  `athlete_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `grade` varchar(255) DEFAULT NULL,
   PRIMARY KEY (`id`),
  FOREIGN KEY (`athlete_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`)
) ;

-- ----------------------------
-- Table structure for project_referee
-- ----------------------------
DROP TABLE IF EXISTS `project_referee`;
CREATE TABLE `project_referee` (
  `id` int(11) NOT NULL auto_increment,
  `referee_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
   PRIMARY KEY (`id`),
  FOREIGN KEY (`referee_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`)
) ;



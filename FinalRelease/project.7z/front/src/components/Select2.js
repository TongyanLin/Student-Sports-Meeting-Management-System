import React from 'react';
import { Menu,Layout,Button} from 'antd';
import { Icon } from '@ant-design/compatible';
const { Sider } = Layout;

class Select2 extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            xmlHttpRequest: null,
            str: ""
        }
        this.AjaxRequest = this.AjaxRequest.bind(this);
        this.ajaxCall = this.ajaxCall.bind(this);
        this.selectOne = this.selectOne.bind(this);
        this.selectOneCall = this.selectOneCall.bind(this);

    }

    componentDidMount() {
        this.AjaxRequest();
    }

    AjaxRequest(){
        const id = this.props.id;
        const userId=this.props.userId;
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/select?id="+id+"&userId="+userId, false);
            this.state.xmlHttpRequest.onreadystatechange = this.ajaxCall;
            this.state.xmlHttpRequest.send();
        }
    }

    ajaxCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;
                this.setState({
                    str:text
                });
            }
        }
    }

    selectOne(){
        const id = this.props.id;
        const userId=this.props.userId;
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/selectOne?id="+id+"&userId="+userId, false);
            this.state.xmlHttpRequest.onreadystatechange = this.selectOneCall;
            this.state.xmlHttpRequest.send();
        }
    }

    selectOneCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;
                this.setState({
                    str:text
                });
            }
        }
    }


    render() {
        const text=this.state.str;
        if(text==1){
            return (
                <span></span>
            );
        }
        else if(text==0){
            return (
                <Button onClick={this.selectOne}>选择</Button>
            );
        }
    }
}

export default Select2;
import React from 'react';
import { Row, Col,Button } from 'antd';
import logo from '../assets/logo.svg';
import logoFont from '../assets/logo-name.svg';
import UserAvatar from "./UserAvator";

class HeaderInfo extends React.Component {
    render() {
        return (
            <div id="header">
                <div id="header-content">
                    <Row>
                        <Col xs={24} sm={24} md={5} lg={5} xl={5} xxl={4}>
                            <a id="logo" href={"/home"}>
                                <img alt="logo"  className="logo" src={logo} style={{ height:45 }}/>
                            </a>
                            学生运动会
                        </Col>
                        <Col xs={0} sm={0} md={19} lg={19} xl={19} xxl={20}>
                            {/*<UserAvatar user="lty"/>*/}
                            <Button>登录</Button>
                        </Col>
                    </Row>
                </div>
            </div>
        );
    }
}

export default HeaderInfo;
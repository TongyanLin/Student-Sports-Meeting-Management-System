import React from 'react';
import { Avatar, Dropdown, Menu} from 'antd';
import { UserOutlined } from '@ant-design/icons';

class UserAvatar extends React.Component {
    render() {
        const menu = (
            <Menu>
                <Menu.Item>
                    <a href="#">
                        Show Profile
                    </a>
                </Menu.Item>
                <Menu.Item>
                    <a href="#">
                        Log Out
                    </a>
                </Menu.Item>
            </Menu>
        );

        const user = this.props.user;

        return(
            <div id="avatar">
                <span className="name">Hi, {user}</span>
                <Dropdown overlay={menu} placement="bottomRight">
                    <Avatar icon={<UserOutlined />} style={{cursor:"pointer"}}/>
                </Dropdown>
            </div>
        );
    }
}

export default UserAvatar;
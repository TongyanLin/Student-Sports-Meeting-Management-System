import React from 'react';
import { Table, InputNumber,Button,Statistic } from 'antd';
import StateComponent3 from "./StateComponent3";

const { Column } = Table;

class Project3Table extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            selectionType:"checkbox",
            xmlHttpRequest:null,
            projects:[],
            str:""
        }
        this.AjaxRequest=this.AjaxRequest.bind(this);
        this.ajaxCall=this.ajaxCall.bind(this);
    }

    componentWillMount() {
        this.AjaxRequest();
    }

    AjaxRequest(){
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/projects", true);
            this.state.xmlHttpRequest.onreadystatechange = this.ajaxCall;
            this.state.xmlHttpRequest.send();
        }
    }

    ajaxCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;

                this.setState({
                    projects:JSON.parse(text),//是个数组
                    str:text
                });
            }
        }
    }



    render() {
        const projects=this.state.projects;
        return (
            <div>
                <Table
                    dataSource={projects}
                >
                    <Column
                        title= '项目'
                        dataIndex='name'
                        render={(text) => <a>{text}</a>}
                    />
                    <Column
                        title= '日期'
                        dataIndex= 'date'
                    />
                    <Column
                        title= '录入成绩'
                        render= {(test,record) => {
                            const id=record.projectId;
                            return <StateComponent3 id={id} />
                        }}
                    />
                </Table>
                {/*<p>*/}
                {/*    {this.state.str}*/}
                {/*</p>*/}
            </div>

        );
    }
}


export default Project3Table;
import React from 'react';
import { Menu,Layout} from 'antd';
import { Icon } from '@ant-design/compatible';
const { Sider } = Layout;

class SideBar extends React.Component {
    constructor(props) {
        super(props);
        this.jump=this.jump.bind(this);
    }
    jump(e){
        window.location.href = e.key;
    }
    render() {
        return (
            <Sider className="sider" width="180px">
                <Menu
                     selectedKeys={[this.props.location]}
                    onClick={this.jump}
                    mode="inline"
                >
                    <Menu.Item key="home" >
                        <Icon type="read" style={{ fontSize: '18px'}}/>
                        <span style={{ fontSize: '16px'}}>Books</span>
                    </Menu.Item>
                    <Menu.Item key="cart">
                        <Icon type="shopping-cart" style={{ fontSize: '18px'}} />
                        <span style={{ fontSize: '16px'}}>My Cart</span>
                    </Menu.Item>
                    <Menu.Item key="orders">
                        <Icon type="solution"  style={{ fontSize: '18px'}}/>
                        <span style={{ fontSize: '16px'}}>My Orders</span>
                    </Menu.Item>
                    <Menu.Item key="profile">
                        <Icon type="user" style={{ fontSize: '18px'}}/>
                        <span style={{ fontSize: '16px'}}>My Profile</span>
                    </Menu.Item>
                </Menu>
            </Sider>
        );
    }
}

export default SideBar;
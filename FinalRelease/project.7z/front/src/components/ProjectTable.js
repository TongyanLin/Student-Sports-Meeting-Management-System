import React from 'react';
import { Table, InputNumber,Button,Statistic } from 'antd';

const { Column } = Table;

class ProjectTable extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            selectionType:"checkbox",
            xmlHttpRequest:null,
            projects:[],
            str:""
        }
        this.AjaxRequest=this.AjaxRequest.bind(this);
        this.ajaxCall=this.ajaxCall.bind(this);
    }

    componentWillMount() {
        this.AjaxRequest();
    }

    AjaxRequest(){
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/projects", false);
            this.state.xmlHttpRequest.onreadystatechange = this.ajaxCall;
            this.state.xmlHttpRequest.send();
        }
    }

    ajaxCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;

                this.setState({
                    projects:JSON.parse(text),//是个数组
                    str:text
                });
            }
        }
    }



    render() {
        const projects=this.state.projects;
        return (
            <div>
                <Table
                    dataSource={projects}
                >
                    <Column
                        title= '项目'
                        render= {(test,record) => {
                            var name=record.name;
                            var id=record.projectId;
                            return <a href={"project?id="+id}>{name}</a>;
                        }}
                    />
                    <Column
                        title= '日期'
                        dataIndex= 'date'
                    />
                </Table>
                {/*<p>*/}
                {/*    {this.state.str}*/}
                {/*</p>*/}
            </div>

        );
    }
}


export default ProjectTable;
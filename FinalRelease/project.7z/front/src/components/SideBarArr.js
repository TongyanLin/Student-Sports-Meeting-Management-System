import React from 'react';
import { Menu,Layout} from 'antd';
import { Icon } from '@ant-design/compatible';
const { Sider } = Layout;

class SideBarArr extends React.Component {
    constructor(props) {
        super(props);
        this.jump=this.jump.bind(this);
    }
    jump(e){
        window.location.href = e.key;
    }
    render() {
        return (
            <Sider className="sider" width="180px">
                <Menu
                    selectedKeys={[this.props.location]}
                    onClick={this.jump}
                    mode="inline"
                >
                    <Menu.Item key="user" >
                        <Icon type="read" style={{ fontSize: '18px'}}/>
                        <span style={{ fontSize: '16px'}}>用户管理</span>
                    </Menu.Item>
                    <Menu.Item key="bookArr">
                        <Icon type="shopping-cart" style={{ fontSize: '18px'}} />
                        <span style={{ fontSize: '16px'}}>书籍管理</span>
                    </Menu.Item>
                    <Menu.Item key="ordersArr">
                        <Icon type="solution"  style={{ fontSize: '18px'}}/>
                        <span style={{ fontSize: '16px'}}>订单管理</span>
                    </Menu.Item>
                    <Menu.Item key="statistics">
                        <Icon type="user" style={{ fontSize: '18px'}}/>
                        <span style={{ fontSize: '16px'}}>统计</span>
                    </Menu.Item>
                </Menu>
            </Sider>
        );
    }
}

export default SideBarArr;
import React from 'react';
import 'antd/dist/antd.css';
import { Form, Input, Button, Checkbox } from 'antd';

class LoginForm extends React.Component{
    constructor(props) {
        super(props);
        this.state={
            xmlHttpRequest:null,
            type:"",
            str:""
        }
        this.onFinish=this.onFinish.bind(this);
        this.onFinishFailed=this.onFinishFailed.bind(this);
        this.ajaxCall=this.ajaxCall.bind(this);
    }

    onFinish(values){
        console.log('Success:', values);
        const username=values.username;
        const psd=values.password;
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/login?username="+username+"&psd="+psd, true);
            this.state.xmlHttpRequest.onreadystatechange = this.ajaxCall;
            this.state.xmlHttpRequest.send();
        }
    };

    ajaxCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;
                const type=text;
                if(type<0){
                    document.getElementById("msg").innerHTML = "<h2> Wrong password</h2>";
                }
                else if(type==0){
                    window.location.href="/manager"
                }
                else if(type==1){
                    window.location.href="/referee"
                }
                else if(type==2){
                    window.location.href="/student"
                }
            }
        }
    }

    onFinishFailed(errorInfo){
        console.log('Failed:', errorInfo);
    };
    render(){
        const layout = {
            labelCol: {
                span: 8,
            },
            wrapperCol: {
                span: 16,
            },
        };
        const tailLayout = {
            wrapperCol: {
                offset: 8,
                span: 16,
            },
        };
        return(
            <div>
                <Form
                    {...layout}
                    name="basic"
                    initialValues={{
                        remember: true,
                    }}
                    className="login-form"
                    onFinish={this.onFinish}
                    onFinishFailed={this.onFinishFailed}
                >
                    <Form.Item
                        label="Username"
                        name="username"
                        rules={[
                            {
                                required: true,
                                message: 'Please input your username!',
                            },
                        ]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label="Password"
                        name="password"
                        rules={[
                            {
                                required: true,
                                message: 'Please input your password!',
                            },
                        ]}
                    >
                        <Input.Password />
                    </Form.Item>

                    <Form.Item {...tailLayout} name="remember" valuePropName="checked">
                        <Checkbox>Remember me</Checkbox>
                    </Form.Item>

                    <Form.Item {...tailLayout}>
                        <Button type="primary" htmlType="submit">
                            Submit
                        </Button>
                    </Form.Item>
                </Form>
                <div id="msg"></div>
                {/*{this.state.type}*/}
            </div>
        );
    }
}

export default LoginForm;
import React from 'react';
import { Descriptions, Badge } from 'antd';

class Profile extends React.Component {
    render() {
        return (
            <Descriptions title="User Info" column={1} bordered>
                <Descriptions.Item label="姓名">hello,you</Descriptions.Item>
                <Descriptions.Item label="身份">顾客</Descriptions.Item>
                <Descriptions.Item label="电话">12345678901</Descriptions.Item>
                <Descriptions.Item label="地址">上海市闵行区东川路800号上海交通大学学生公寓</Descriptions.Item>
            </Descriptions>
        );
    }
}


export default Profile;
import React from 'react';
import {Card, Descriptions, Button, Table, Input} from 'antd';
import Select from "./Select";
import Select2 from "./Select2";

const { Column } = Table;

class ProjectEdit extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            project:{},
            xmlHttpRequest:null,
            str:"",
            referees:[]
        };
        this.AjaxRequest=this.AjaxRequest.bind(this);
        this.ajaxCall=this.ajaxCall.bind(this);
        this.AjaxRequest2=this.AjaxRequest2.bind(this);
        this.ajaxCall2=this.ajaxCall2.bind(this);
        this.changeName=this.changeName.bind(this);
        this.changeNameCall=this.changeNameCall.bind(this);
        this.changeDate=this.changeDate.bind(this);
        this.changeDateCall=this.changeDateCall.bind(this);
        this.adopt=this.adopt.bind(this);
        this.adoptCall=this.adoptCall.bind(this);
    }

    componentWillMount() {
        this.AjaxRequest();
        this.AjaxRequest2();
    }

    AjaxRequest(){
        const id = this.props.id;
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/findProject?id="+id, false);
            this.state.xmlHttpRequest.onreadystatechange = this.ajaxCall;
            this.state.xmlHttpRequest.send();
        }
    }

    ajaxCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;
                this.setState({
                    project:JSON.parse(text),
                    str:text
                });
            }
        }
    }

    AjaxRequest2(){
        // const id = this.props.id;
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/referees", false);
            this.state.xmlHttpRequest.onreadystatechange = this.ajaxCall2;
            this.state.xmlHttpRequest.send();
        }
    }

    ajaxCall2() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;
                this.setState({
                    referees:JSON.parse(text),
                    // str:text
                });
            }
        }
    }

    changeName(){
        const id = this.props.id;
        const name=document.getElementById("changeName").value;
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/changeName?id="+id+"&name="+name, false);
            this.state.xmlHttpRequest.onreadystatechange = this.changeNameCall;
            this.state.xmlHttpRequest.send();
        }
    }

    changeNameCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;
                this.setState({
                    str:text
                });
            }
        }
    }

    changeDate(){
        const id = this.props.id;
        const date=document.getElementById("changeDate").value;
        // alert(id);
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/changeDate?id="+id+"&date="+date, false);
            this.state.xmlHttpRequest.onreadystatechange = this.changeDateCall;
            this.state.xmlHttpRequest.send();
        }
    }

    changeDateCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;
                this.setState({
                    str:text
                });
            }
        }
    }

    adopt(e){
        const id = this.props.id;
        const userId=e.target.value;
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/adopt?id="+id+"&userId="+userId, false);
            this.state.xmlHttpRequest.onreadystatechange = this.adoptCall;
            this.state.xmlHttpRequest.send();
        }
    }

    adoptCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;
                this.setState({
                    project:JSON.parse(text),
                    str:text
                });
            }
        }
    }

    render() {
        const project=this.state.project;
        const referees=this.state.referees;
        const athletes=this.state.project.athletes;

        return (
            <div>
                <Descriptions title="赛事信息" column={2} bordered>
                    <Descriptions.Item label="比赛项目">
                        <Input id="changeName" defaultValue={project.name} />
                        <Button onClick={this.changeName}>保存</Button>
                    </Descriptions.Item>
                    <Descriptions.Item label="比赛日程">
                        <Input id="changeDate" defaultValue={project.date} />
                        <Button onClick={this.changeDate}>保存</Button>
                    </Descriptions.Item>
                </Descriptions>
                <p>裁判安排</p>
                <Table
                    dataSource={referees}
                >
                    <Column
                        title= '姓名'
                        dataIndex='username'
                    />
                    <Column
                        title= '状态'
                        render= {(test,record) => {
                            const id = this.props.id;
                            const userId=record.userId;
                            return <Select id={id} userId={userId}/>;
                        }}
                    />
                    <Column
                        title= '操作'
                        render= {(test,record) => {
                            const id = this.props.id;
                            const userId=record.userId;
                            return <Select2 id={id} userId={userId}/>;
                        }}
                    />
                </Table>
                <p>参赛学生</p>
                <Table
                    dataSource={athletes}
                >
                    <Column
                        title= '姓名'
                        render= {(test,record) => {
                            var name=record.athlete.username;
                            return (<span>
                                {name}
                            </span>);
                        }}
                    />
                    <Column
                        title= '状态'
                        render= {(test,record) => {
                            var type=record.state;
                            if(type==1){
                                return (<span>
                                等待审核
                            </span>);
                            }
                            else if(type==2) {
                                return (<span>
                                审核通过
                            </span>);
                            }
                        }}
                    />
                    <Column
                        title= '操作'
                        render= {(test,record) => {
                            var id=record.athlete.userId;
                            var type=record.state;
                            if(type==1){
                                return (<span>
                                <button value={id} onClick={this.adopt}>通过</button>
                            </span>);
                            }
                        }}
                    />
                </Table>
                <Button>确定</Button>
                {/*{this.state.str}*/}
            </div>
        );
    }
}


export default ProjectEdit;
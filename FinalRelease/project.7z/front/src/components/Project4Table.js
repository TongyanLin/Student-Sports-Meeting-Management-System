import React from 'react';
import { Table, InputNumber,Button,Statistic } from 'antd';

const { Column } = Table;

class Project4Table extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            selectionType:"checkbox",
            xmlHttpRequest:null,
            projects:[],
            str:""
        }
        this.AjaxRequest=this.AjaxRequest.bind(this);
        this.ajaxCall=this.ajaxCall.bind(this);
        this.delete=this.delete.bind(this);
        this.deleteCall=this.deleteCall.bind(this);
        this.edit=this.edit.bind(this);
        this.add=this.add.bind(this);
        this.addCall=this.addCall.bind(this);
    }

    componentWillMount() {
        this.AjaxRequest();
    }

    AjaxRequest(){
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/projects", false);
            this.state.xmlHttpRequest.onreadystatechange = this.ajaxCall;
            this.state.xmlHttpRequest.send();
        }
    }

    ajaxCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;

                this.setState({
                    projects:JSON.parse(text),//是个数组
                    str:text
                });
            }
        }
    }

    delete(e){
        const id=e.target.value;
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/delete?id="+id, false);
            this.state.xmlHttpRequest.onreadystatechange = this.ajaxCall;
            this.state.xmlHttpRequest.send();
        }
    }

    deleteCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;

                this.setState({
                    projects:JSON.parse(text),//是个数组
                    str:text
                });
            }
        }
    }

    edit(e){
        const id=e.target.value;
        window.open("/projectEdit?id="+id);
    }

    add(){
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/add", false);
            this.state.xmlHttpRequest.onreadystatechange = this.ajaxCall;
            this.state.xmlHttpRequest.send();
        }
    }

    addCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;
                if(text>0){
                    window.open("/projectEdit?id="+text);
                }
            }
        }
    }

    render() {
        const projects=this.state.projects;
        return (
            <div>
                <Table
                    dataSource={projects}
                >
                    <Column
                        title= '项目'
                        dataIndex='name'
                        render={(text) => <a>{text}</a>}
                    />
                    <Column
                        title= '日期'
                        dataIndex= 'date'
                    />
                    <Column
                        title= '操作'
                        render= {(test,record) => {
                            var id=record.projectId;
                            return (<span>
                                <button value={id} onClick={this.delete}>删除</button>
                                <button value={id} onClick={this.edit}>编辑</button>
                            </span>);
                        }}
                    />
                </Table>
                {/*<p>*/}
                {/*    {this.state.str}*/}
                {/*</p>*/}
                <Button onClick={this.add}>增加</Button>
            </div>

        );
    }
}


export default Project4Table;
import React from 'react';
import { Menu,Layout,Button} from 'antd';
import { Icon } from '@ant-design/compatible';
const { Sider } = Layout;

class StateComponent3 extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            xmlHttpRequest: null,
            state:"",
            str: ""
        }
        this.AjaxRequest = this.AjaxRequest.bind(this);
        this.ajaxCall = this.ajaxCall.bind(this);
        this.gradeEdit=this.gradeEdit.bind(this);
        this.gradeEditCall=this.gradeEditCall.bind(this);
    }

    componentDidMount() {
        this.AjaxRequest();
    }

    AjaxRequest(){
        const id = this.props.id;
        // alert(id);
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/getState3?id="+id, false);
            this.state.xmlHttpRequest.onreadystatechange = this.ajaxCall;
            this.state.xmlHttpRequest.send();
        }
    }

    ajaxCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;
                const id="project"+this.props.id;
                this.setState({
                    projects:JSON.parse(text),//是个数组
                    str:text
                });
            }
        }
    }

    gradeEdit() {
        const id = this.props.id;
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/gradeEdit?id="+id, false);
            this.state.xmlHttpRequest.onreadystatechange = this.gradeEditCall;
            this.state.xmlHttpRequest.send();

        }
    }

    gradeEditCall(){
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;
                this.setState({
                    str:text
                });
            }
        }
    }

    render() {
        const text=this.state.str;
        const id="project"+this.props.id;
        if(text==1){
            return (
                <Button onClick={this.gradeEdit}>录入成绩</Button>
            );
        }
        else if(text==0){
            return (<div></div>);
        }
    }
}

export default StateComponent3;
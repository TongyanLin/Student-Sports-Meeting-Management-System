import React from 'react';
import { Table, InputNumber,Button,Statistic } from 'antd';

const columns = [
    {
        title: '书籍',
        dataIndex: 'book',
        render: (text) => <a>{text}</a>,
    },
    {
        title: '单价',
        dataIndex: 'price',
        render: (text) => <span>${text}</span>,
    },
    {
        title: '数量',
        dataIndex: 'number',
        render: (text) => <InputNumber min={0} max={1000} defaultValue={text} />,
    },
    {
        title: '金额',
        dataIndex: 'money',
        render: (text) => <span>${text}</span>,
    },
];
const data = [
    {
        key: '1',
        book: 'Java核心技术卷II',
        price: 32,
        number: 1,
        money: 32,
    },
    {
        key: '2',
        book: '深入理解计算机系统',
        price: 42,
        number: 2,
        money: 84,
    },
    {
        key: '3',
        book: 'Effective C++',
        price: 32,
        number: 3,
        money: 96,
    },
    {
        key: '4',
        book: '小王子',
        price: 99,
        number: 4,
        money: 396,
    },
]; // rowSelection object indicates the need for row selection

const rowSelection = {
    onChange: (selectedRowKeys, selectedRows) => {
        console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
    },
};

class Cart extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            selectionType:"checkbox"
        }
    }
    render() {
        const selectionType=this.state.selectionType;
        return (
            <div>
                <Table
                    rowSelection={{
                        type: selectionType,
                        ...rowSelection,
                    }}
                    columns={columns}
                    dataSource={data}
                />
                <Statistic title="合计" value={608} precision={2} prefix="$"/>
                <Button>删除</Button>
                <Button type="primary">结算</Button>
            </div>

        );
    }
}


export default Cart;
import React from 'react';
import { Table, InputNumber,Button,Statistic } from 'antd';

const { Column } = Table;

const rowSelection = {
    onChange: (selectedRowKeys, selectedRows) => {
        console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
    },
};

class UserTable extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            selectionType:"checkbox",
            xmlHttpRequest:null,
            users:[],
        }
        this.AjaxRequest=this.AjaxRequest.bind(this);
        this.ajaxCall=this.ajaxCall.bind(this);
        this.prohibit=this.prohibit.bind(this);
        this.unProhibit=this.unProhibit.bind(this);
        this.pro=this.pro.bind(this);
        this.unPro=this.unPro.bind(this);
    }

    componentWillMount() {
        this.AjaxRequest();
    }

    AjaxRequest(){
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/users", false);
            this.state.xmlHttpRequest.onreadystatechange = this.ajaxCall;
            this.state.xmlHttpRequest.send();
        }
    }

    ajaxCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;

                this.setState({
                    users:JSON.parse(text)//是个数组
                });
            }
        }
    }

    prohibit(e){
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            const id=e.target.value;
            // alert(id);
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/prohibit?id="+id, false);
            this.state.xmlHttpRequest.onreadystatechange = this.pro;
            this.state.xmlHttpRequest.send();
        }
    }

    pro(){
        this.setState({});
    }

    unProhibit(e){
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            const id=e.target.value;
            // alert(id);
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/unProhibit?id="+id, false);
            this.state.xmlHttpRequest.onreadystatechange = this.unPro;
            this.state.xmlHttpRequest.send();
        }
    }

    unPro(){
        this.setState({});
    }

    render() {
        const selectionType=this.state.selectionType;
        return (
            <div>
                <Table
                    rowSelection={{
                        type: selectionType,
                        ...rowSelection,
                    }}
                    // columns={columns}
                    dataSource={this.state.users}
                >
                    <Column
                        title= '用户名'
                        dataIndex='username'
                        render={(text) => <a>{text}</a>}
                    />
                    <Column
                        title= '密码'
                        dataIndex= 'password'
                    />
                    <Column
                        title= '身份'
                        dataIndex= 'type'
                        render={ (type) => {
                            var s="普通用户";
                            if(type===1){
                            s="被禁用户";
                            }
                            if(type===2){
                            s="管理员";
                            }
                            return <span>{s}</span>;
                        }}
                    />
                    <Column
                        title= '操作'
                        render= {(test,record) => {
                            var type=record.type;
                            var id=record.userId;
                            var x;
                            if(type===0){
                                x=<button value={id} onClick={this.prohibit}>禁用</button>;
                            }
                            if(type===1){
                                x=<button value={id} onClick={this.unProhibit}>解禁</button>;
                            }
                            if(type===2){
                                x=<span></span>;
                            }
                            return x;
                        }}
                    />
                </Table>
                {/*<p>*/}
                {/*    {this.state.users[1].username}*/}
                {/*    {this.state.users[1].type}*/}
                {/*</p>*/}
            </div>

        );
    }
}


export default UserTable;
import React from 'react';
import {Card, Descriptions, Button, Table, InputNumber} from 'antd';

const { Column } = Table;

class ProjectDetail extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            project:{},
            xmlHttpRequest:null,
            str:""
        };
        this.AjaxRequest=this.AjaxRequest.bind(this);
        this.ajaxCall=this.ajaxCall.bind(this);
    }

    componentWillMount() {
        this.AjaxRequest();
    }

    AjaxRequest(){
        const id = this.props.id;
        // alert(id);
        if (window.XMLHttpRequest) {
            this.state.xmlHttpRequest = new XMLHttpRequest();
        }
        if (this.state.xmlHttpRequest != null) {
            this.state.xmlHttpRequest.withCredentials = true;
            this.state.xmlHttpRequest.open(
                "GET", "http://localhost:8080/findProject?id="+id, false);
            this.state.xmlHttpRequest.onreadystatechange = this.ajaxCall;
            this.state.xmlHttpRequest.send();
        }
    }

    ajaxCall() {
        if (this.state.xmlHttpRequest.readyState == 4) {
            if (this.state.xmlHttpRequest.status == 200) {
                const text = this.state.xmlHttpRequest.responseText;
                this.setState({
                    project:JSON.parse(text),
                    str:text
                });
            }
        }
    }


    render() {
        const project=this.state.project;
        const referees=this.state.project.referees;
        const athletes=this.state.project.athletes;

        return (
            <div>
                <Descriptions title="赛事信息" column={2} bordered>
                    <Descriptions.Item label="比赛项目">{project.name}</Descriptions.Item>
                    <Descriptions.Item label="比赛日程">{project.date}</Descriptions.Item>
                </Descriptions>
                <p>比赛裁判</p>
                <Table
                    dataSource={referees}
                >
                    <Column
                        title= '姓名'
                        render= {(test,record) => {
                            var name=record.referee.username;
                            return (<span>
                                {name}
                            </span>);
                        }}
                    />
                </Table>
                <p>比赛成绩</p>
                <Table
                    dataSource={athletes}
                >
                    <Column
                        title= '姓名'
                        render= {(test,record) => {
                            var name=record.athlete.username;
                            return (<span>
                                {name}
                            </span>);
                        }}
                    />
                    <Column
                        title= '状态'
                        render= {(test,record) => {
                            var type=record.state;
                            if(type==1){
                                return (<span>
                                等待审核
                            </span>);
                            }
                            else if(type==2) {
                                return (<span>
                                审核通过
                            </span>);
                            }
                        }}
                    />
                    <Column
                        title= '成绩'
                        dataIndex= 'grade'
                        render={(text) => {
                            if(text!=null){
                                return (<span>
                                {text}
                            </span>);
                            }
                            else {
                                return (<span>
                                    还未录入
                            </span>);
                            }
                        }}
                    />
                </Table>
                {/*<p>{this.state.str}</p>*/}
            </div>
        );
    }
}


export default ProjectDetail;
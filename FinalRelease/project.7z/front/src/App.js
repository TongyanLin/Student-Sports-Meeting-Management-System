import './App.css';
import React from 'react';
import {BrowserRouter as Router, Switch, Route} from "react-router-dom";
import LoginView from "./view/LoginView";
import HomeView from "./view/HomeView";
import ProjectView from "./view/ProjectView";
import RefereeView from "./view/RefereeView";
import StudentView from "./view/StudentView";
import EditGradeView from "./view/EditGradeView";
import ManagerView from "./view/ManagerView";
import ProjectEditView from "./view/ProjectEditView";

class App extends React.Component {
  render() {
    return (
        <Router>
          <Switch>
            <Route exact path="/" component={LoginView} />
            <Route exact path="/login" component={LoginView} />
            <Route exact path="/home" component={HomeView} />
            <Route exact path="/project" component={ProjectView} />
            <Route exact path="/referee" component={RefereeView} />
            <Route exact path="/student" component={StudentView} />
            <Route exact path="/grade" component={EditGradeView} />
            <Route exact path="/manager" component={ManagerView} />
            <Route exact path="/projectEdit" component={ProjectEditView} />
          </Switch>
        </Router>
    );
  }
}

export default App;

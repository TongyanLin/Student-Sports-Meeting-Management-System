import React from 'react';
import 'antd/dist/antd.css';
import { Layout } from 'antd';
import "../css/index.css"
import HeaderInfo2 from "../components/HeaderInfo2";
import Project4Table from "../components/Project4Table";

const { Header, Content } = Layout;

class ManagerView extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <Layout className="layout">
                <Header>
                    <HeaderInfo2/>
                </Header>
                <Layout>
                    <Content style={{ padding: '0 50px' }}>
                        <div className="profile-content">
                            <Project4Table/>
                        </div>
                    </Content>
                </Layout>
            </Layout>
        );
    }
}


export default ManagerView;
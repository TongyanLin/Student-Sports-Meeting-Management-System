import React from 'react';
import LoginForm from "../components/LoginForm";
import "../css/login.css";
import logo from "../assets/logo.svg";
import logoFont from "../assets/logo-name.svg";

class LoginView extends React.Component{
    render(){
        return(
            <div className="login-page">
                <div>
                    <div className="login-title">
                        <img alt="logo"  className="logo" src={logo} style={{ height:75 }}/>
                        <h1> Login to eBook</h1>
                    </div>
                    <div className="login-box">
                        <LoginForm />
                    </div>
                </div>
            </div>
        );
    }
}

export default LoginView;
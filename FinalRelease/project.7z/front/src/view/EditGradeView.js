import React from 'react';
import 'antd/dist/antd.css';
import { Layout } from 'antd';
import '../css/home.css'
import "../css/index.css"
import HeaderInfo2 from "../components/HeaderInfo2";
import EditGrade from "../components/EditGrade";
import ProjectDetail from "../components/ProjectDetail";

const { Header, Content } = Layout;

class EditGradeView extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        const param = this.props.location.search;
        const id = param.substr(4);
        return (
            <Layout className="layout">
                <Header>
                    <HeaderInfo2/>
                </Header>
                <Layout>
                    <Content style={{ padding: '0 50px' }}>
                        <div className="home-content">
                            <EditGrade  id={id}/>
                        </div>
                    </Content>
                </Layout>
            </Layout>
        );
    }
}


export default EditGradeView;
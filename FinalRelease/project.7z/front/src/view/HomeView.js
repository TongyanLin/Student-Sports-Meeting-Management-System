import React from 'react';
import 'antd/dist/antd.css';
import { Layout } from 'antd';
import '../css/home.css'
import "../css/index.css"
import HeaderInfo from "../components/HeaderInfo";
import ProjectTable from "../components/ProjectTable";

const { Header, Content } = Layout;

class HomeView extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <Layout className="layout">
                <Header>
                    <HeaderInfo/>
                </Header>
                <Layout>
                    <Content style={{ padding: '0 50px' }}>
                        <div className="home-content">
                            <ProjectTable/>
                        </div>
                    </Content>
                </Layout>
            </Layout>
        );
    }
}


export default HomeView;
import React from 'react';
import 'antd/dist/antd.css';
import { Layout } from 'antd';
import "../css/index.css"
import HeaderInfo2 from "../components/HeaderInfo2";
import Project3Table from "../components/Project3Table";

const { Header, Content } = Layout;

class RefereeView extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <Layout className="layout">
                <Header>
                    <HeaderInfo2/>
                </Header>
                <Layout>
                    <Content style={{ padding: '0 50px' }}>
                        <div className="cart-content">
                            <Project3Table/>
                        </div>
                    </Content>
                </Layout>
            </Layout>
        );
    }
}


export default RefereeView;
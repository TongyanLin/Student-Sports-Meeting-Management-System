import React from 'react';
import 'antd/dist/antd.css';
import { Layout } from 'antd';
import '../css/home.css'
import "../css/index.css"
import SideBar from "../components/SideBar";
import HeaderInfo2 from "../components/HeaderInfo2";
import ProjectDetail from "../components/ProjectDetail";

const { Header, Content } = Layout;

class ProjectView extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        const param = this.props.location.search;
        const id = param.substr(4);
        return (
            <Layout className="layout">
                <Header>
                    <HeaderInfo2/>
                </Header>
                <Layout>
                    {/*<SideBar location="home"/>*/}
                    <Content style={{ padding: '0 50px' }}>
                        <div className="home-content">
                            <ProjectDetail id={id}/>
                        </div>
                    </Content>
                </Layout>
            </Layout>
        );
    }
}


export default ProjectView;
package test.com.example.demo.entity;

import com.example.demo.entity.Project;
import com.example.demo.entity.ProjectAthlete;
import com.example.demo.entity.ProjectReferee;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;

import java.util.Set;

/**
* Project Tester.
*
* @author <Authors name>
* @since <pre>6月 25, 2021</pre>
* @version 1.0
*/
public class ProjectTest {
Project test = new Project();
@Before
public void before() throws Exception {
}

@After
public void after() throws Exception {
}

/**
*
* Method: getProjectId()
*
*/
@Test
public void testGetProjectId() throws Exception {
//TODO: Test goes here...
    test.getProjectId();
    System.out.println("getProjectId()");
}

/**
*
* Method: setProjectId(int projectId)
*
*/
@Test
public void testSetProjectId() throws Exception {
//TODO: Test goes here...

    test.setProjectId(1);
    System.out.println("setProjectId()");
}

/**
*
* Method: getName()
*
*/
@Test
public void testGetName() throws Exception {
//TODO: Test goes here...
    test.getName();
    System.out.println("getName()");
}

/**
*
* Method: setName(String name)
*
*/
@Test
public void testSetName() throws Exception {
//TODO: Test goes here...
    test.setName("zhl");
    System.out.println("getName()");
}

/**
*
* Method: getDate()
*
*/
@Test
public void testGetDate() throws Exception {
//TODO: Test goes here...
    test.getDate();
    System.out.println("getDate()");
}

/**
*
* Method: setDate(String date)
*
*/
@Test
public void testSetDate() throws Exception {
//TODO: Test goes here...
    test.setDate("2021-7-1");
    System.out.println("setDate()");
}

/**
*
* Method: getAthletes()
*
*/
@Test
public void testGetAthletes() throws Exception {
//TODO: Test goes here...
    test.getAthletes();
    System.out.println("getAthletes()");
}

/**
*
* Method: setAthletes(Set<ProjectAthlete> athletes)
*
*/
@Test
public void testSetAthletes() throws Exception {
//TODO: Test goes here...
    Set<ProjectAthlete> athletes = null;
    test.setAthletes(athletes);
    System.out.println("setAthletes()");
}

/**
*
* Method: getReferees()
*
*/
@Test
public void testGetReferees() throws Exception {
//TODO: Test goes here...
    test.getReferees();
    System.out.println("getReferees()");
}

/**
*
* Method: setReferees(Set<ProjectReferee> referees)
*
*/
@Test
public void testSetReferees() throws Exception {
//TODO: Test goes here...
    Set<ProjectReferee> referees = null;
    test.setReferees(referees);
    System.out.println("setReferees()");
}


}

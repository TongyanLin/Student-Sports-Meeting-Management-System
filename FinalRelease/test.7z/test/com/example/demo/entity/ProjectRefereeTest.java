package test.com.example.demo.entity;

import com.example.demo.entity.Project;
import com.example.demo.entity.ProjectReferee;
import com.example.demo.entity.User;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;

/**
* ProjectReferee Tester.
*
* @author <Authors name>
* @since <pre>6月 25, 2021</pre>
* @version 1.0
*/
public class ProjectRefereeTest {
ProjectReferee test = new ProjectReferee();
@Before
public void before() throws Exception {
}

@After
public void after() throws Exception {
}

/**
*
* Method: getId()
*
*/
@Test
public void testGetId() throws Exception {
//TODO: Test goes here...
    test.getId();
    System.out.println("getId()");
}

/**
*
* Method: setId(int id)
*
*/
@Test
public void testSetId() throws Exception {
//TODO: Test goes here...
    test.setId(1);
    System.out.println("setId()");
}

/**
*
* Method: getProject()
*
*/
@Test
public void testGetProject() throws Exception {
//TODO: Test goes here...
    test.getProject();
    System.out.println("getProject()");
}

/**
*
* Method: setProject(Project project)
*
*/
@Test
public void testSetProject() throws Exception {
//TODO: Test goes here...
    Project project = new Project();
    test.setProject(project);
    System.out.println("setProject()");
}

/**
*
* Method: getAthlete()
*
*/
@Test
public void testGetAthlete() throws Exception {
//TODO: Test goes here...
    test.getAthlete();
    System.out.println("getAthlete()");
}

/**
*
* Method: setAthlete(User athlete)
*
*/
@Test
public void testSetAthlete() throws Exception {
//TODO: Test goes here...
    User a = new User();
    test.setAthlete(a);
    System.out.println("setAthlete()");
}


}

package test.com.example.demo.entity;

import com.example.demo.entity.Project;
import com.example.demo.entity.ProjectAthlete;
import com.example.demo.entity.User;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;

import java.util.Arrays;

/**
* ProjectAthlete Tester.
*
* @author <Authors name>
* @since <pre>6月 25, 2021</pre>
* @version 1.0
*/
public class ProjectAthleteTest {
ProjectAthlete test = new ProjectAthlete();
@Before
public void before() throws Exception {
}

@After
public void after() throws Exception {
}

/**
*
* Method: getId()
*
*/
@Test
public void testGetId() throws Exception {
//TODO: Test goes here...
    int id = test.getId();
    System.out.println(Arrays.toString(new String[]{"getId()=" + id}));
}

/**
*
* Method: setId(int id)
*
*/
@Test
public void testSetId() throws Exception {
//TODO: Test goes here...
    test.setId(1);
    System.out.println("setId()");
}

/**
*
* Method: getProject()
*
*/
@Test
public void testGetProject() throws Exception {
//TODO: Test goes here...
    test.getProject();
    System.out.println("getProject()");
}

/**
*
* Method: setProject(Project project)
*
*/
@Test
public void testSetProject() throws Exception {
//TODO: Test goes here...
    Project project = new Project();
    test.setProject(project);
    System.out.println("setProject()");
}

/**
*
* Method: getAthlete()
*
*/
@Test
public void testGetAthlete() throws Exception {
//TODO: Test goes here...
    test.getAthlete();
    System.out.println("getAthlete()");
}

/**
*
* Method: setAthlete(User athlete)
*
*/
@Test
public void testSetAthlete() throws Exception {
//TODO: Test goes here...
    User user = new User();
    test.setAthlete(user);
    System.out.println("setAthlete()");
}

/**
*
* Method: getGrade()
*
*/
@Test
public void testGetGrade() throws Exception {
//TODO: Test goes here...
    test.getGrade();
    System.out.println("getGrade()");
}

/**
*
* Method: setGrade(String grade)
*
*/
@Test
public void testSetGrade() throws Exception {
//TODO: Test goes here...
    test.setGrade("100");
    System.out.println("setGrade()");
}

/**
*
* Method: getState()
*
*/
@Test
public void testGetState() throws Exception {
//TODO: Test goes here...
    test.getState();
    System.out.println("getState()");
}

/**
*
* Method: setState(int state)
*
*/
@Test
public void testSetState() throws Exception {
//TODO: Test goes here...
    test.setState(1);
    System.out.println("setState()");
}


}

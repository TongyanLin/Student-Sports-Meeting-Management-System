package test.com.example.demo.entity;

import com.example.demo.entity.ProjectReferee;
import com.example.demo.entity.User;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;

import java.util.Set;

/**
* User Tester.
*
* @author <Authors name>
* @since <pre>6月 25, 2021</pre>
* @version 1.0
*/
public class UserTest {
User test= new User();
@Before
public void before() throws Exception {
}

@After
public void after() throws Exception {
}

/**
*
* Method: getUserId()
*
*/
@Test
public void testGetUserId() throws Exception {
//TODO: Test goes here...
    test.getUserId();
    System.out.println("getUserId()");
}

/**
*
* Method: setUserId(int userId)
*
*/
@Test
public void testSetUserId() throws Exception {
//TODO: Test goes here...
    test.setUserId(1);
    System.out.println("setUserId()");
}

/**
*
* Method: getUsername()
*
*/
@Test
public void testGetUsername() throws Exception {
//TODO: Test goes here...
    test.getUsername();
    System.out.println("getUserName()");
}

/**
*
* Method: setUsername(String username)
*
*/
@Test
public void testSetUsername() throws Exception {
//TODO: Test goes here...
    test.setUsername("zhl");
    System.out.println("setUsername()");
}

/**
*
* Method: getPassword()
*
*/
@Test
public void testGetPassword() throws Exception {
//TODO: Test goes here...
    test.getPassword();
    System.out.println("getPassword()");
}

/**
*
* Method: setPassword(String password)
*
*/
@Test
public void testSetPassword() throws Exception {
//TODO: Test goes here...
    test.setPassword("123");
    System.out.println("setPassword()");
}

/**
*
* Method: getType()
*
*/
@Test
public void testGetType() throws Exception {
//TODO: Test goes here...
    test.getType();
    System.out.println("getType()");
}

/**
*
* Method: setType(int type)
*
*/
@Test
public void testSetType() throws Exception {
//TODO: Test goes here...
    test.setType(1);
    System.out.println("setType()");
}

/**
*
* Method: getProjects()
*
*/
@Test
public void testGetProjects() throws Exception {
//TODO: Test goes here...
    test.getProjects();
    System.out.println("getProjects()");
}

/**
*
* Method: setProjects(Set<ProjectAthlete> projects)
*
*/
@Test
public void testSetProjects() throws Exception {
//TODO: Test goes here...
    test.setProjects(null);
    System.out.println("srtProjects()");
}

/**
*
* Method: getProjects2()
*
*/
@Test
public void testGetProjects2() throws Exception {
//TODO: Test goes here...
    Object o = new Object();
    test.getProjects2(o);
    System.out.println("getProjects2()");
}

/**
*
* Method: setProjects2(Set<ProjectReferee> projects2)
*
*/
@Test
public void testSetProjects2() throws Exception {
//TODO: Test goes here...
    test.setProjects2(null);
    System.out.println("setProjects2()");
}


}

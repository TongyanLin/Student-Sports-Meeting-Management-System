package test.com.example.demo.serviceimpl;

import com.example.demo.serviceimpl.UserServiceImpl;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;

/**
* UserServiceImpl Tester.
*
* @author <Authors name>
* @since <pre>6月 25, 2021</pre>
* @version 1.0
*/
public class UserServiceImplTest {
UserServiceImpl test = new UserServiceImpl();
@Before
public void before() throws Exception {
}

@After
public void after() throws Exception {
}

/**
*
* Method: checkUser(String username, String password)
*
*/
@Test
public void testCheckUser() throws Exception {
//TODO: Test goes here...
    test.checkUser("zhl","123");
    System.out.println("checkUser()");
}


}

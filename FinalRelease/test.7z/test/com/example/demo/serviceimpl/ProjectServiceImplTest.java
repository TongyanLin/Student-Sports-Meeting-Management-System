package test.com.example.demo.serviceimpl;

import com.example.demo.serviceimpl.ProjectServiceImpl;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;

/**
* ProjectServiceImpl Tester.
*
* @author <Authors name>
* @since <pre>6月 25, 2021</pre>
* @version 1.0
*/
public class ProjectServiceImplTest {
ProjectServiceImpl test = new ProjectServiceImpl();
@Before
public void before() throws Exception {
}

@After
public void after() throws Exception {
}

/**
*
* Method: getProjects()
*
*/
@Test
public void testGetProjects() throws Exception {
//TODO: Test goes here...
    test.getProjects();
    System.out.println("getProjects()");
}

/**
*
* Method: findProject(Integer id)
*
*/
@Test
public void testFindProject() throws Exception {
//TODO: Test goes here...
    test.findProject(1);
    System.out.println("findProject()");
}

/**
*
* Method: getState(Integer userId, Integer projectId)
*
*/
@Test
public void testGetState() throws Exception {
//TODO: Test goes here...
    test.getState(1,2);
    System.out.println("getState()");
}

/**
*
* Method: signup(Integer userId, Integer projectId)
*
*/
@Test
public void testSignup() throws Exception {
//TODO: Test goes here...
    test.signup(1,2);
    System.out.println("signup()");
}

/**
*
* Method: getState3(Integer userId, Integer projectId)
*
*/
@Test
public void testGetState3() throws Exception {
//TODO: Test goes here...
    test.getState3(1,2);
    System.out.println("getState3()");
}

/**
*
* Method: changeName(Integer projectId, String name)
*
*/
@Test
public void testChangeName() throws Exception {
//TODO: Test goes here...
    test.changeName(1,"zhl");
    System.out.println("changeName()");
}

/**
*
* Method: changeDate(Integer projectId, String date)
*
*/
@Test
public void testChangeDate() throws Exception {
//TODO: Test goes here...
    test.changeDate(1,"2021-7-1");
    System.out.println("changeDate()");
}

/**
*
* Method: add()
*
*/
@Test
public void testAdd() throws Exception {
//TODO: Test goes here...
    test.add();
    System.out.println("add()");
}

/**
*
* Method: delete(Integer projectId)
*
*/
@Test
public void testDelete() throws Exception {
//TODO: Test goes here...
    test.delete(1);
    System.out.println("delete()");
}

/**
*
* Method: adopt(Integer userId, Integer projectId)
*
*/
@Test
public void testAdopt() throws Exception {
//TODO: Test goes here...
    test.adopt(1,2);
    System.out.println("adopt()");
}


}

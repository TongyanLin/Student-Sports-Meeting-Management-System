package test.com.example.demo.daoimpl;

import com.example.demo.daoimpl.ProjectRefereeDaoImpl;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;

/**
* ProjectRefereeDaoImpl Tester.
*
* @author <Authors name>
* @since <pre>6月 25, 2021</pre>
* @version 1.0
*/
public class ProjectRefereeDaoImplTest {
ProjectRefereeDaoImpl test = new ProjectRefereeDaoImpl();
@Before
public void before() throws Exception {
}

@After
public void after() throws Exception {
}

/**
*
* Method: getState(Integer userId, Integer projectId)
*
*/
@Test
public void testGetState() throws Exception {
//TODO: Test goes here...
    test.getState(1,2);
    System.out.println("getState()");
}


}

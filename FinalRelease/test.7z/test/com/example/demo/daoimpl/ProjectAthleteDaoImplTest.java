package test.com.example.demo.daoimpl;

import com.example.demo.dao.ProjectAthleteDao;
import com.example.demo.daoimpl.ProjectAthleteDaoImpl;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
* ProjectAthleteDaoImpl Tester.
*
* @author <Authors name>
* @since <pre>6月 25, 2021</pre>
* @version 1.0
*/
public class ProjectAthleteDaoImplTest {
ProjectAthleteDaoImpl test = new ProjectAthleteDaoImpl();
@Before
public void before() throws Exception {
}

@After
public void after() throws Exception {
}

/**
*
* Method: getState(Integer userId, Integer projectId)
*
*/
@Test
public void testGetState() throws Exception {
//TODO: Test goes here...
    test.getState(1,2);
    System.out.println("getState()");

}

/**
*
* Method: signup(Integer userId, Integer projectId)
*
*/
@Test
public void testSignup() throws Exception {
//TODO: Test goes here...
    test.signup(1,2);
    System.out.println("signup()");
}

/**
*
* Method: adopt(Integer userId, Integer projectId)
*
*/
@Test
public void testAdopt() throws Exception {
//TODO: Test goes here...
    test.adopt(1,2);
    System.out.println("adopt()");
}


}

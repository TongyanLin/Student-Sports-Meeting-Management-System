package test.com.example.demo.daoimpl;

import com.example.demo.daoimpl.ProjectDaoImpl;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;

/**
* ProjectDaoImpl Tester.
*
* @author <Authors name>
* @since <pre>6月 25, 2021</pre>
* @version 1.0
*/
public class ProjectDaoImplTest {
ProjectDaoImpl test = new ProjectDaoImpl();
@Before
public void before() throws Exception {
}

@After
public void after() throws Exception {
}

/**
*
* Method: getAll()
*
*/
@Test
public void testGetAll() throws Exception {
//TODO: Test goes here...
    test.getAll();
    System.out.println("getAll()");
}

/**
*
* Method: findProject(Integer id)
*
*/
@Test
public void testFindProject() throws Exception {
//TODO: Test goes here...
    test.findProject(1);
    System.out.println("findProject()");
}

/**
*
* Method: changeName(Integer projectId, String name)
*
*/
@Test
public void testChangeName() throws Exception {
//TODO: Test goes here...
    test.changeName(1,"zhl");
    System.out.println("changeName()");
}

/**
*
* Method: changeDate(Integer projectId, String date)
*
*/
@Test
public void testChangeDate() throws Exception {
//TODO: Test goes here...
    test.changeDate(1,"2021-7-1");
    System.out.println("changeDate()");
}

/**
*
* Method: add()
*
*/
@Test
public void testAdd() throws Exception {
//TODO: Test goes here...
    test.add();
    System.out.println("add()");
}

/**
*
* Method: delete(Integer projectId)
*
*/
@Test
public void testDelete() throws Exception {
//TODO: Test goes here...
    test.delete(1);
    System.out.println("delete()");
}


}

package test.com.example.demo.daoimpl;

import com.example.demo.daoimpl.UserDaoImpl;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;

/**
* UserDaoImpl Tester.
*
* @author <Authors name>
* @since <pre>6月 25, 2021</pre>
* @version 1.0
*/
public class UserDaoImplTest {
UserDaoImpl test = new UserDaoImpl();
@Before
public void before() throws Exception {
}

@After
public void after() throws Exception {
}

/**
*
* Method: checkUser(String username, String password)
*
*/
@Test
public void testCheckUser() throws Exception {
//TODO: Test goes here...
    test.checkUser("zhl","123");
    System.out.println("checkUser()");
}


}

package test.com.example.demo.controller;

import com.example.demo.controller.UserController;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
* UserController Tester.
*
* @author <Authors name>
* @since <pre>6月 25, 2021</pre>
* @version 1.0
*/
public class UserControllerTest {
UserController testusercontroller = new UserController();
@Before
public void before() throws Exception {
}

@After
public void after() throws Exception {
}

/**
*
* Method: user(@RequestParam("username") String username, @RequestParam("psd") String password, HttpServletRequest request, HttpServletResponse response)
*
*/
@Test
public void testUser() throws Exception {
//TODO: Test goes here...
    HttpServletRequest request = null;
    HttpServletResponse response = null;
    assert false;
    testusercontroller.user("zhl","123",request, response);
    System.out.println("user()");
}


}

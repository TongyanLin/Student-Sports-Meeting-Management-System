package test.com.example.demo.controller;

import com.example.demo.controller.ProjectController;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Before;
import org.junit.Test;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.http.HttpRequest;

/**
* ProjectController Tester.
*
* @author <Authors name>
* @since <pre>6月 25, 2021</pre>
* @version 1.0
*/
public class ProjectControllerTest {

    ProjectController testprojectcontroller = new ProjectController();
@Before("")
public void before() throws Exception {
}

@After("")
public void after() throws Exception {
}

/**
*
* Method: getProjects(HttpServletRequest request, HttpServletResponse response)
*
*/
@Test
public void testGetProjects() throws Exception {
//TODO: Test goes here...
    HttpServletRequest request = null;
    HttpServletResponse response = null;
    assert false;
    testprojectcontroller.getProjects(request, response);
    System.out.println("getProjects()");
}

/**
*
* Method: findProject(@RequestParam("id") Integer id, HttpServletRequest request, HttpServletResponse response)
*
*/
@Test
public void testFindProject() throws Exception {
//TODO: Test goes here...
    HttpServletRequest request = null;
    HttpServletResponse response = null;
    assert false;
    testprojectcontroller.findProject(1,request, response);
    System.out.println("findProject()");
}

/**
*
* Method: getState(@RequestParam("id") Integer projectId, HttpServletRequest request, HttpServletResponse response)
*
*/
@Test
public void testGetState() throws Exception {
//TODO: Test goes here...
    HttpServletRequest request = null;
    HttpServletResponse response = null;
    assert false;
    testprojectcontroller.getState(1,request, response);
    System.out.println("getState()");
}

/**
*
* Method: signup(@RequestParam("id") Integer projectId, HttpServletRequest request, HttpServletResponse response)
*
*/
@Test
public void testSignup() throws Exception {
//TODO: Test goes here...
    HttpServletRequest request = null;
    HttpServletResponse response = null;
    assert false;
    testprojectcontroller.signup(1,request, response);
    System.out.println("signup()");
}

/**
*
* Method: getState3(@RequestParam("id") Integer projectId, HttpServletRequest request, HttpServletResponse response)
*
*/
@Test
public void testGetState3() throws Exception {
//TODO: Test goes here...
    HttpServletRequest request = null;
    HttpServletResponse response = null;
    assert false;
    testprojectcontroller.getState3(1,request, response);
    System.out.println("getState3()");
}

/**
*
* Method: changeName(@RequestParam("id") Integer projectId, @RequestParam("name") String name, HttpServletRequest request, HttpServletResponse response)
*
*/
@Test
public void testChangeName() throws Exception {
//TODO: Test goes here...
    HttpServletRequest request = null;
    HttpServletResponse response = null;
    assert false;
    testprojectcontroller.changeName(1,"zhl",request, response);
    System.out.println("changeName()");
}

/**
*
* Method: changeDate(@RequestParam("id") Integer projectId, @RequestParam("date") String date, HttpServletRequest request, HttpServletResponse response)
*
*/
@Test
public void testChangeDate() throws Exception {
//TODO: Test goes here...
    HttpServletRequest request = null;
    HttpServletResponse response = null;
    assert false;
    testprojectcontroller.changeDate(1,"2021-7-1",request, response);
    System.out.println("changeDate()");
}

/**
*
* Method: add(HttpServletRequest request, HttpServletResponse response)
*
*/
@Test
public void testAdd() throws Exception {
//TODO: Test goes here...
    HttpServletRequest request = null;
    HttpServletResponse response = null;
    assert false;
    testprojectcontroller.add(request, response);
    System.out.println("add()");
}

/**
*
* Method: delete(@RequestParam("id") Integer projectId, HttpServletRequest request, HttpServletResponse response)
*
*/
@Test
public void testDelete() throws Exception {
//TODO: Test goes here...
    HttpServletRequest request = null;
    HttpServletResponse response = null;
    assert false;
    testprojectcontroller.delete(1,request, response);
    System.out.println("delete()");
}

/**
*
* Method: adopt(@RequestParam("id") Integer projectId, @RequestParam("userId") Integer userId, HttpServletRequest request, HttpServletResponse response)
*
*/
@Test
public void testAdopt() throws Exception {
//TODO: Test goes here...
    HttpServletRequest request = null;
    HttpServletResponse response = null;
    assert false;
    testprojectcontroller.adopt(1,2,request, response);
    System.out.println("adopt()");
}


}
